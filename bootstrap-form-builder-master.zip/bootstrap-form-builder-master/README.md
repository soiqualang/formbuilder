### A Simple Form Builder for Bootstrap 3

- Drag and Drop Elements and get HTML.
- Support single / 2 column layouts.
- Edit html on individual elements.

### Use It Now:

[http://frappe.github.io/bootstrap-form-builder/](http://frappe.github.io/bootstrap-form-builder/)

### License

MIT
