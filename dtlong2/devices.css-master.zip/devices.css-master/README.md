See the demo [here](http://marvelapp.github.io/devices.css/)

# Usage
In order to use a device, include devices.min.css at the top of your document and then go back to the [demo](http://marvelapp.github.io/devices.css/) and select the combination you want, and simply copy out the generated HTML. That's it!

This will give you the device you selected, just like we use on Marvel. Use them, tweak them and improve however you want! Also sign up for [Marvel](http://marvelapp.com) if you haven't already because it's pretty good