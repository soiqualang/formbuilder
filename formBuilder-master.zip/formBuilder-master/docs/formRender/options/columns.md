# formRender Columns

I hesitated even putting this in the Docs but some found it useful. It possible to render columns by field type, however I would recommend writing some additional JS to work as an addon in the editing to give your users control over which fields should be rendered as columns.
<p data-height="300" data-theme-id="22927" data-slug-hash="MKXybG" data-default-tab="result" data-user="kevinchappell" data-embed-version="2" class="codepen"></p>
