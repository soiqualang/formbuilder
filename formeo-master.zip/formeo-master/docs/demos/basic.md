# Basic

A basic Formeo instance. Click or drag an input to the stage.
<p data-height="550" data-theme-id="0" data-slug-hash="NAXoRw" data-default-tab="result" data-user="kevinchappell" class="codepen"></p>
