# formRender `formData` option

Pass formData to formRender through a configuration Object:
<p data-height="360" data-theme-id="22927" data-slug-hash="bprXzw" data-default-tab="js,result" data-user="kevinchappell" data-embed-version="2" class="codepen"></p>
